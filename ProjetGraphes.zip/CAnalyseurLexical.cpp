#include "CAnalyseurLexical.h"


const char* pcANLJetons[] = {"NBSommets", "NBArcs", "Sommets", "Numero", "Arcs", "Debut", "Fin", "=", "[", "]"};

typedef enum jetonsGraphes
{
	NBSOMMETS_JETON,
	NBARCS_JETON,
	DEBUT_LISTE_SOMMETS_JETON,
	NUMERO_JETON,
	DEBUT_LISTE_ARCS_JETON,
	DEBUT_ARC_JETON,
	FIN_ARC_JETON,
	EGAL_JETON,
	DEBUT_LISTE_JETON,
	FIN_LISTE_JETON,
};

/****************************************************************************************************************
***** CAnalyseurLexical : constructeur par d�faut de la classe CAnalyseurLexical							*****
*****************************************************************************************************************
***** Entr�e :	Rien			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction initialise un analyseur lexical												*****
*****************************************************************************************************************/

CAnalyseurLexical::CAnalyseurLexical()
{
	pcANLChemin = nullptr;
}


/****************************************************************************************************************
***** CAnalyseurLexical : constructeur de recopie de la classe CAnalyseurLexical							*****
*****************************************************************************************************************
***** Entr�e :	CAnalyseurLexical : ANLParam			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction initialise un analyseur lexical � partir d'un autre analyseur lexical			*****
*****************************************************************************************************************/

CAnalyseurLexical::CAnalyseurLexical(CAnalyseurLexical& ANLParam)
{
	//longueur du chemin en param�tre en comptant le caract�re de fin de chaine
	unsigned int uiLongeurChaine = strlen(ANLParam.pcANLChemin) + 1;

	//on cr�e le chemin
	pcANLChemin = new char[uiLongeurChaine];

	//copie de la chaine ITEParam.pcChemin dans pcChemin
	strcpy_s(pcANLChemin, uiLongeurChaine, ANLParam.pcANLChemin);
}


/****************************************************************************************************************
***** CAnalyseurLexical : constructeur de confort de la classe CAnalyseurLexical							*****
*****************************************************************************************************************
***** Entr�e :	char * : pcCheminParam			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction initialise un analyseur lexical � partir d'un chemin de fichier				*****
*****************************************************************************************************************/

CAnalyseurLexical::CAnalyseurLexical(const char* pcCheminParam)
{
	//longueur de la chapine en param�tre en comptant le caract�re de fin de chaine
	unsigned int uiLongeurChaine = strlen(pcCheminParam) + 1;

	pcANLChemin = new char[strlen(pcCheminParam) + 1];

	//copie de la chaine pcCheminFichier dans pcChemin
	strcpy_s(pcANLChemin, uiLongeurChaine, pcCheminParam);
}


/****************************************************************************************************************
***** ~CAnalyseurLexical : destructeur de la classe CAnalyseurLexical										*****
*****************************************************************************************************************
***** Entr�e :	Rien			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction d�salloue l'espace m�moire attribu� � l'analyseur lexical						*****
*****************************************************************************************************************/

CAnalyseurLexical::~CAnalyseurLexical()
{
	delete pcANLChemin;
}


//Accesseur en �criture de chaine
void CAnalyseurLexical::ANLModifierChaine(const char* pcNouvelleChaine)
{
	delete pcANLChemin;

	unsigned int uiLongeurChaine = strlen(pcNouvelleChaine) + 1;

	pcANLChemin = new char[strlen(pcNouvelleChaine) + 1];

	//copie de la chaine pcCheminFichier dans pcChemin
	strcpy_s(pcANLChemin, uiLongeurChaine, pcNouvelleChaine);
}

char** CAnalyseurLexical::ANLLireFichier()
{
	
	ifstream IFSFichier(pcANLChemin);

	//Teste si le fichier est bien ouvert
	if (!IFSFichier)
	{
		cout << "chemin invalide\n";
		CException EXCException(CHEMIN_INVALIDE);
		throw EXCException;
	}

	
	return nullptr;
}