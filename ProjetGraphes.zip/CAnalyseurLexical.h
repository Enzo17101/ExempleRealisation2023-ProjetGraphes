#pragma once
#include <iostream>
#include <fstream>
#include <cstring>

#include "CException.h"

using namespace std;

/*
#define NBSOMMETS_JETON "NBSommets"
#define NBARCS_JETON "NBArcs"
#define DEBUT_LISTE_SOMMETS_JETON "Sommets"
#define NUMERO_JETON "Numero"
#define DEBUT_LISTE_ARCS_JETON "Arcs"
#define DEBUT_ARC_JETON "Debut"
#define FIN_ARC_JETON "Fin"

#define EGAL_JETON '='
#define DEBUT_LISTE_JETON '['
#define FIN_LISTE_JETON ']'
*/

class CAnalyseurLexical
{

private:
	//Attribut
	char* pcANLChemin;
	
	
public:

	//Constructeurs et destructeurs

	/****************************************************************************************************************
	***** CAnalyseurLexical : constructeur par d�faut de la classe CAnalyseurLexical							*****
	*****************************************************************************************************************
	***** Entr�e :	Rien			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction initialise un analyseur lexical												*****
	*****************************************************************************************************************/
	CAnalyseurLexical();

	/****************************************************************************************************************
	***** CAnalyseurLexical : constructeur de recopie de la classe CAnalyseurLexical							*****
	*****************************************************************************************************************
	***** Entr�e :	AnalyseurLexical : ANLParam			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction initialise un analyseur lexical � partir d'un autre analyseur lexical			*****
	*****************************************************************************************************************/
	CAnalyseurLexical(CAnalyseurLexical& ANLParam);

	/****************************************************************************************************************
	***** CAnalyseurLexical : constructeur de confort de la classe CAnalyseurLexical							*****
	*****************************************************************************************************************
	***** Entr�e :	char * : pcCheminParam			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction initialise un analyseur lexical � partir d'un chemin de fichier				*****
	*****************************************************************************************************************/
	CAnalyseurLexical(const char * pcCheminParam);

	/****************************************************************************************************************
	***** ~CAnalyseurLexical : destructeur de la classe CAnalyseurLexical										*****
	*****************************************************************************************************************
	***** Entr�e :	Rien			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction d�salloue l'espace m�moire attribu� � l'analyseur lexical						*****
	*****************************************************************************************************************/
	~CAnalyseurLexical();

	//M�thodes et fonctions

	//Ces accesseurs permettent de modifier un analyseur lexical, cela gagne du temps et du code, car il �vite
	//d'avoir � delete puis r�instancier un nouvel analyseur lexical lorsque l'on a plusieurs chaines � tester successivement
	void ANLModifierChaine(const char* pcNouveauChemin);
	

	//Parcours du fichier caract�re par caract�re pour sortir une liste des tokens sous forme de liste de char *
	char ** ANLLireFichier();
	
};

