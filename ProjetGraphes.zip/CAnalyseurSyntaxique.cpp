#include "CAnalyseurSyntaxique.h"

/****************************************************************************************************************
***** CAnalyseurSyntaxique : constructeur par d�faut de la classe CAnalyseurSyntaxique							*****
*****************************************************************************************************************
***** Entr�e :	Rien			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction initialise un analyseur syntaxique												*****
*****************************************************************************************************************/

CAnalyseurSyntaxique::CAnalyseurSyntaxique()
{
	pcANSChemin = nullptr;
}

/****************************************************************************************************************
***** CAnalyseurSyntaxique : constructeur de recopie de la classe CAnalyseurSyntaxique							*****
*****************************************************************************************************************
***** Entr�e :	CAnalyseurSyntaxique : ANSParam			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction initialise un analyseur syntaxique � partir d'un autre analyseur syntaxique			*****
*****************************************************************************************************************/

CAnalyseurSyntaxique::CAnalyseurSyntaxique(CAnalyseurSyntaxique& ANSParam)
{
	//Longueur du chemin en param�tre en comptant le caract�re de fin de chaine
	unsigned int uiLongueurChemin = strlen(ANSParam.pcANSChemin) + 1;

	pcANSChemin = new char[uiLongueurChemin];

	//Copie de la chaine ITEParam.pcANSChemin dans pcANSChemin
	strcpy_s(pcANSChemin, uiLongueurChemin, ANSParam.pcANSChemin);
}

/****************************************************************************************************************
***** CAnalyseurSyntaxique : constructeur de confort de la classe CAnalyseurSyntaxique							*****
*****************************************************************************************************************
***** Entr�e : char* : pcANSCheminFichier			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction initialise un analyseur syntaxique � partir d'une chaine de caract�re				*****
*****************************************************************************************************************/

CAnalyseurSyntaxique::CAnalyseurSyntaxique(const char* pcANSCheminFichier)
{
	//Longueur du chemin en param�tre en comptant le caract�re de fin de chaine
	unsigned int uiLongueurChemin = strlen(pcANSCheminFichier) + 1;

	pcANSChemin = new char[uiLongueurChemin];

	//Copie de la chaine ITEParam.pcANSChemin dans pcANSChemin
	strcpy_s(pcANSChemin, uiLongueurChemin, pcANSCheminFichier);
}


/****************************************************************************************************************
***** ~CAnalyseurSyntaxique : destructeur la classe CAnalyseurSyntaxique									*****
*****************************************************************************************************************
***** Entr�e :	Rien			                                                                            *****
***** N�cessite : Rien				                                                                        *****
***** Sortie : Rien								                                                            *****
***** Entraine : La fonction d�salloue l'espace m�moire allou� � un CAnalyseurSyntaxique					*****
*****************************************************************************************************************/

CAnalyseurSyntaxique::~CAnalyseurSyntaxique()
{
	delete pcANSChemin;
}

CGraphe& CAnalyseurSyntaxique::ANSGenererGraphe()
{
	CGraphe* monGraphe = new CGraphe();
	// TODO: ins�rer une instruction return ici
	return *monGraphe;
}
