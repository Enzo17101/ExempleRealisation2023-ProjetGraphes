#pragma once


#include "CException.h"
#include "CAnalyseurLexical.h"
#include "CGraphe.h"

#include <cstring>
#include <fstream>

/*
#define SYNTAXE_INVALIDE 10
#define CHEMIN_INVALIDE 11
*/

class CAnalyseurSyntaxique
{
private:
	//Attribut
	char* pcANSChemin;

public:
	//Constructeurs et destructeurs

	/****************************************************************************************************************
	***** CAnalyseurSyntaxique : constructeur par d�faut de la classe CAnalyseurSyntaxique						*****
	*****************************************************************************************************************
	***** Entr�e :	Rien			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction initialise un analyseur syntaxique												*****
	*****************************************************************************************************************/
	CAnalyseurSyntaxique();

	/****************************************************************************************************************
	***** CAnalyseurSyntaxique : constructeur de recopie de la classe CAnalyseurSyntaxique						*****
	*****************************************************************************************************************
	***** Entr�e :	Rien			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction initialise un analyseur syntaxique � partir d'un autre analyseur syntaxique	*****
	*****************************************************************************************************************/
	CAnalyseurSyntaxique(CAnalyseurSyntaxique& ANSParam);


	/****************************************************************************************************************
	***** CAnalyseurSyntaxique : constructeur de confort de la classe CAnalyseurSyntaxique						*****
	*****************************************************************************************************************
	***** Entr�e :	Rien			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction initialise un analyseur syntaxique � partir d'une chaine de caract�re			*****
	*****************************************************************************************************************/
	CAnalyseurSyntaxique(const char* pcCheminFichier);


	/****************************************************************************************************************
	***** ~CAnalyseurSyntaxique : destructeur la classe CAnalyseurSyntaxique									*****
	*****************************************************************************************************************
	***** Entr�e :	Rien			                                                                            *****
	***** N�cessite : Rien				                                                                        *****
	***** Sortie : Rien								                                                            *****
	***** Entraine : La fonction d�salloue l'espace m�moire allou� � un CAnalyseurSyntaxique					*****
	*****************************************************************************************************************/
	~CAnalyseurSyntaxique();

	CGraphe& ANSGenererGraphe();
};